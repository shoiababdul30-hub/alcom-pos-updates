// ALCOM POS — protected build (compiled program)
require('bytenode');
require('./alcom-tools.jsc');
