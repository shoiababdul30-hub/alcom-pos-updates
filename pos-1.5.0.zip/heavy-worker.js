// ALCOM POS — protected build (compiled program)
require('bytenode');
require('./heavy-worker.bundle.jsc');
