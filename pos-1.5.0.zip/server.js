// ALCOM POS — protected build (compiled program)
const fs = require('fs');
const path = require('path');
try {
  const home = process.env.ALCOM_HOTEL_DIR ? path.resolve(process.env.ALCOM_HOTEL_DIR) : __dirname;
  const up = path.join(home, 'data', 'updates');
  const ready = path.join(up, 'ready.json');
  const staged = path.join(up, 'staged');
  if (fs.existsSync(ready) && fs.existsSync(path.join(staged, 'server.bundle.jsc'))) {
    const v = JSON.parse(fs.readFileSync(ready, 'utf8')).version;
    fs.cpSync(staged, __dirname, { recursive: true, force: true });
    fs.rmSync(staged, { recursive: true, force: true });
    fs.renameSync(ready, path.join(up, 'installed-' + v + '.json'));
    console.log('[update] installed version ' + v);
  }
} catch (e) {
  console.error('[update] could not install the update:', e.message);
}
require('bytenode');
require('./server.bundle.jsc');
